# security_monitor.py
def validate_lm_request(text: str):
    if contains_pii(text):
        raise SecurityViolation("PII detected in LM input")
        
    if not is_tls_1_3(current_connection()):
        raise SecurityViolation("Insecure connection for LM service")

def log_security_incident(error: Exception, context: str):
    with open("/security/logs/audit.log", "a") as f:
        f.write(f"{datetime.utcnow()} | {context} | {str(error)}\n")
    alert_security_team(context)