# quantization.py
model = AutoModelForCausalLM.from_pretrained("finbert-tone")
quantized_model = quantize_dynamic(
    model,
    {nn.Linear},
    dtype=torch.qint8,
    inplace=False
)
torch.save(quantized_model.state_dict(), "quantized_model.pth")