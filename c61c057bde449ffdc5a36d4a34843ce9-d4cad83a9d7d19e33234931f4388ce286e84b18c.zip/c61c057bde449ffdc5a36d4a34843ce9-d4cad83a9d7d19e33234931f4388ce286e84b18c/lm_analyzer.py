# lm_analyzer.py
class FinancialTextAnalyzer:
    def __init__(self):
        self.model = AutoModelForCausalLM.from_pretrained("/app/model")
        self.tokenizer = AutoTokenizer.from_pretrained("finbert-tone")
        self.cache = LRUCache(maxsize=1000)
        
    def analyze(self, text: str) -> float:
        if cached := self.cache.get(text):
            return cached
            
        inputs = self.tokenizer(
            f"[FIN_ANALYSIS]{text}[/FIN_ANALYSIS]",
            return_tensors="pt",
            truncation=True,
            max_length=512
        )
        
        with torch.inference_mode():
            outputs = self.model(**inputs)
            
        sentiment = self._extract_sentiment(outputs.logits)
        self.cache[text] = sentiment
        return sentiment

    def _extract_sentiment(self, logits: Tensor) -> float:
        # Custom financial sentiment head
        return torch.sigmoid(logits[:, -1]).item()