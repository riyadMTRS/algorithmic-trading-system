# smc_controller.py
class SMCFlow:
    def __init__(self):
        self.ml_client = MLAnalyzerClient("grpc://ml-service:50051")
        self.lm_client = LMAnalyzerClient("grpc://lm-service:50052")
        self.fallback = RuleBasedFallback()

    async def handle_liquidity_event(self, event: LiquidityEvent):
        # Parallel execution with timeout
        try:
            ml_task = asyncio.create_task(self.ml_client.analyze(event.numeric_data))
            lm_task = asyncio.create_task(self.lm_client.analyze(event.text_data))
            
            done, pending = await asyncio.wait(
                [ml_task, lm_task],
                timeout=0.1,  # 100ms SLA
                return_when=asyncio.ALL_COMPLETED
            )
            
            if ml_task in done and lm_task in done:
                return self._fusion_layer(ml_task.result(), lm_task.result())
            else:
                return await self.fallback.execute(event)
                
        except Exception as e:
            log_security_incident(e, "SMC_ANALYZE_LM_ERROR")
            return self.fallback.execute(event)

    def _fusion_layer(self, ml_score: float, lm_score: float) -> Action:
        weights = self._load_weights_from_security_policy()  # SECURITY.md compliance
        combined = (weights.ml * ml_score) + (weights.lm * lm_score)
        return OrderExecution() if combined > thresholds.ACTION else NoOp()